import {FC,PropsWithChildren} from "react"

interface Props {

}
const TheFooter: FC<PropsWithChildren<Props>> = ({ children }) => {
  return <footer></footer>;
};
export default TheFooter
