export const TOKEN = "ACCESS_TOKEN"
export const FALLBACK_ERROR_MESSAGE = "Unknown Error: something went wrong, please try again later.";
