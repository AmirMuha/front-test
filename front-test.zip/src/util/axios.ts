import axios from "axios"
axios.defaults.baseURL = "https://front-api-test.wsafar.com";

export default axios
